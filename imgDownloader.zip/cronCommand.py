57 * * * * python3 /home/gza060625/Desktop/AU/logSatelliteWeather/smallFunctions.py 
#51 * * * * python3 smallFunctions.py 
#52 * * * * python3 smallFunctions.py 
